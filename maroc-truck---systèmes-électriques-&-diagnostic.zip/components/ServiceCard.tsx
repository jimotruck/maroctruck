
import React from 'react';
import { Service } from '../types';

interface ServiceCardProps {
  service: Service;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service }) => {
  return (
    <div className="group p-8 bg-zinc-900/50 border border-zinc-800 rounded-2xl hover:border-green-500/50 transition-all duration-300 hover:shadow-[0_0_30px_-5px_rgba(34,197,94,0.15)]">
      <div className="w-14 h-14 bg-zinc-800 rounded-xl flex items-center justify-center mb-6 group-hover:bg-green-600 transition-colors duration-300">
        <div className="text-green-500 group-hover:text-white transition-colors duration-300">
          {service.icon}
        </div>
      </div>
      <h3 className="text-xl font-bold mb-4 group-hover:text-yellow-500 transition-colors">{service.title}</h3>
      <p className="text-zinc-400 text-sm leading-relaxed">
        {service.description}
      </p>
    </div>
  );
};

export default ServiceCard;
