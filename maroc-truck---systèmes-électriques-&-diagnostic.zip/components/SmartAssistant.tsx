
import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, X, Bot, Loader2, Mic } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

const SmartAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'bot'; content: string }[]>([
    { role: 'bot', content: 'Bonjour ! Je suis l\'assistant intelligent de MAROC TRUCK. Décrivez-moi un symptôme ou un code défaut sur votre camion pour une première analyse.' }
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!query.trim() || loading) return;

    const userMessage = query;
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setQuery('');
    setLoading(true);

    try {
      // Corrected: Initializing GoogleGenAI using a named parameter and process.env.API_KEY directly.
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Tu es l'assistant expert de "MAROC TRUCK", une entreprise marocaine spécialisée dans l'électricité et le diagnostic de camions poids lourds (DAF, Volvo, Scania, Mercedes-Benz, Renault Trucks, etc.). 
        Réponds de manière professionnelle en français, avec une touche de courtoisie marocaine. 
        Si l'utilisateur donne un code défaut (ex: SPN, FMI) ou un problem électrique, donne une piste technique possible tout en rappelant de contacter MAROC TRUCK pour une intervention physique.
        
        Question client: ${userMessage}`,
      });

      const text = response.text || "Désolé, je rencontre une petite difficulté technique. Veuillez nous contacter par téléphone.";
      setMessages(prev => [...prev, { role: 'bot', content: text }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'bot', content: "Erreur de connexion. Nos techniciens sont disponibles au +212 5XX XX XX XX." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-green-600 hover:bg-green-700 text-white p-4 rounded-full shadow-2xl transition-all transform hover:scale-110 flex items-center gap-2 group"
        >
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 ease-in-out whitespace-nowrap font-bold">
            Assistant Diagnostic
          </span>
          <MessageSquare className="w-6 h-6" />
        </button>
      )}

      {isOpen && (
        <div className="bg-zinc-900 border border-zinc-800 w-80 sm:w-96 rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-4">
          {/* Header */}
          <div className="bg-zinc-800 p-4 flex items-center justify-between border-b border-zinc-700">
            <div className="flex items-center gap-3">
              <div className="bg-green-600 p-2 rounded-lg">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-sm">IA MAROC TRUCK</h3>
                <span className="text-green-500 text-[10px] flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                  Expert en ligne
                </span>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-zinc-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="h-80 overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-zinc-700">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-3 rounded-2xl text-xs leading-relaxed ${
                  m.role === 'user' 
                  ? 'bg-green-600 text-white rounded-tr-none' 
                  : 'bg-zinc-800 text-zinc-200 rounded-tl-none border border-zinc-700'
                }`}>
                  {m.content}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-zinc-800 p-3 rounded-2xl rounded-tl-none border border-zinc-700">
                  <Loader2 className="w-4 h-4 animate-spin text-green-500" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-zinc-800">
            <div className="relative">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Code défaut ou symptôme..."
                className="w-full bg-zinc-950 border border-zinc-700 rounded-full py-2.5 pl-4 pr-12 text-sm focus:outline-none focus:border-green-500 transition-colors"
              />
              <button
                onClick={handleSend}
                disabled={loading}
                className="absolute right-2 top-1.5 p-1 text-green-500 hover:text-green-400 disabled:opacity-50"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
            <p className="text-[10px] text-zinc-500 mt-2 text-center">
              Analyse assistée par IA pour information préliminaire uniquement.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default SmartAssistant;
