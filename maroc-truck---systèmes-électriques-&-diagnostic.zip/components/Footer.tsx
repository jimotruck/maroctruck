
import React from 'react';
import { Link } from 'react-router-dom';
import { Truck, MapPin, Phone, Mail, Facebook, Linkedin, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-zinc-950 border-t border-zinc-800 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <Truck className="w-8 h-8 text-green-500" />
              <span className="text-2xl font-bold">MAROC <span className="text-yellow-500">TRUCK</span></span>
            </div>
            <p className="text-zinc-400 text-sm leading-relaxed">
              Leader du diagnostic poids lourds au Maroc. Nous apportons des solutions technologiques avancées pour la maintenance de votre flotte de camions.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="p-2 bg-zinc-900 rounded-full hover:bg-green-600 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 bg-zinc-900 rounded-full hover:bg-green-600 transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 bg-zinc-900 rounded-full hover:bg-green-600 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-6">Liens Rapides</h3>
            <ul className="space-y-4">
              <li><Link to="/" className="text-zinc-400 hover:text-green-500 transition-colors">Accueil</Link></li>
              <li><Link to="/about" className="text-zinc-400 hover:text-green-500 transition-colors">À Propos</Link></li>
              <li><Link to="/services" className="text-zinc-400 hover:text-green-500 transition-colors">Nos Services</Link></li>
              <li><Link to="/why-us" className="text-zinc-400 hover:text-green-500 transition-colors">Pourquoi Nous</Link></li>
              <li><Link to="/contact" className="text-zinc-400 hover:text-green-500 transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-bold mb-6">Nos Spécialités</h3>
            <ul className="space-y-4">
              <li className="text-zinc-400">Diagnostic Multi-marques</li>
              <li className="text-zinc-400">Programmation ECU</li>
              <li className="text-zinc-400">Systèmes Électriques</li>
              <li className="text-zinc-400">Analyse Codes Défauts</li>
              <li className="text-zinc-400">Maintenance Préventive</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-bold mb-6">Contactez-nous</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-yellow-500 mt-0.5 shrink-0" />
                <span className="text-zinc-400">Zone Industrielle, Casablanca, Maroc</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-yellow-500 shrink-0" />
                <span className="text-zinc-400">+212 5XX XX XX XX</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-yellow-500 shrink-0" />
                <span className="text-zinc-400">contact@maroctruck.ma</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-zinc-800 pt-8 mt-8 text-center text-zinc-500 text-sm">
          <p>© {new Date().getFullYear()} MAROC TRUCK. Tous droits réservés. Propulsé par l'innovation.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
