
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Zap, Shield, Cpu, Clock, Truck } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="relative overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center pt-20">
        {/* Background Overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&q=80&w=2000" 
            alt="Truck Engine Diagnostic" 
            className="w-full h-full object-cover opacity-30 grayscale"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/90 to-transparent"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/10 border border-green-500/20 mb-6 animate-in fade-in slide-in-from-left duration-700">
              <Zap className="w-4 h-4 text-yellow-500" />
              <span className="text-green-500 text-xs font-bold uppercase tracking-widest">N°1 du Diagnostic au Maroc</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-extrabold mb-6 leading-[1.1]">
              MAROC TRUCK – <span className="gradient-text">Systèmes Électriques</span> & Diagnostic Poids Lourds
            </h1>
            <p className="text-zinc-400 text-lg md:text-xl mb-10 max-w-2xl leading-relaxed">
              Expertise de pointe en électronique et diagnostic multi-marques pour vos flottes de poids lourds. Réduction du temps d'immobilisation et optimisation des performances.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                to="/services" 
                className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-full font-bold flex items-center justify-center gap-2 transition-all group"
              >
                Nos Services
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link 
                to="/contact" 
                className="border border-zinc-700 hover:border-zinc-500 bg-zinc-900/50 backdrop-blur px-8 py-4 rounded-full font-bold text-center transition-all"
              >
                Contactez-nous
              </Link>
            </div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute bottom-0 right-0 p-12 hidden lg:block animate-pulse">
          <div className="w-64 h-64 border-[30px] border-yellow-500/10 rounded-full"></div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 border-y border-zinc-800 bg-zinc-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            {[
              { label: 'Interventions / An', value: '1500+' },
              { label: 'Marques Supportées', value: '12+' },
              { label: 'Satisfaction Client', value: '98%' },
              { label: 'Années d\'Expertise', value: '15+' },
            ].map((stat, i) => (
              <div key={i} className="p-6">
                <div className="text-4xl md:text-5xl font-black text-yellow-500 mb-2">{stat.value}</div>
                <div className="text-zinc-500 font-medium uppercase tracking-tighter text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Intro Feature Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="aspect-square bg-zinc-800 rounded-3xl overflow-hidden shadow-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=1000" 
                  alt="High Tech Diagnostic" 
                  className="w-full h-full object-cover opacity-80"
                />
              </div>
              <div className="absolute -bottom-10 -right-10 bg-green-600 p-8 rounded-3xl shadow-2xl hidden md:block">
                <Cpu className="w-12 h-12 text-white mb-4" />
                <div className="text-white font-bold text-lg">Technologie ECU</div>
                <div className="text-green-100 text-sm">Programmation avancée</div>
              </div>
            </div>

            <div>
              <h2 className="text-4xl font-bold mb-8 leading-tight">
                Votre partenaire de confiance pour la <span className="text-green-500">santé électronique</span> de vos camions.
              </h2>
              <p className="text-zinc-400 mb-10 leading-relaxed text-lg">
                Chez MAROC TRUCK, nous comprenons que chaque minute d'immobilisation de votre flotte représente un coût. Nos techniciens spécialisés utilisent les derniers outils de diagnostic pour identifier et résoudre les problèmes complexes sur vos systèmes électriques et électroniques.
              </p>
              
              <div className="space-y-6">
                {[
                  { icon: <Shield className="w-5 h-5" />, title: 'Fiabilité Certifiée', desc: 'Processus de diagnostic rigoureux.' },
                  { icon: <Clock className="w-5 h-5" />, title: 'Intervention Rapide', desc: 'Déplacement sur site possible.' },
                  { icon: <Truck className="w-5 h-5" />, title: 'Multi-marques', desc: 'Compétences sur tous les constructeurs.' },
                ].map((item, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-zinc-800 rounded-xl flex items-center justify-center text-yellow-500">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="font-bold text-zinc-100">{item.title}</h4>
                      <p className="text-zinc-500 text-sm">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
