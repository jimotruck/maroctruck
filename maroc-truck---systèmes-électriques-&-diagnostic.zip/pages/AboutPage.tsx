
import React from 'react';
import { Target, Lightbulb, Users, Award } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h1 className="text-4xl md:text-6xl font-black mb-6">À Propos de <span className="gradient-text">MAROC TRUCK</span></h1>
          <p className="text-zinc-400 max-w-3xl mx-auto text-lg leading-relaxed">
            Passionnés par la mécanique de précision et l'innovation électronique, nous sommes la référence du diagnostic poids lourds au Royaume du Maroc.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-16 mb-24 items-center">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-zinc-100">Notre Histoire & Vision</h2>
            <p className="text-zinc-400 leading-relaxed">
              Fondée pour répondre à la complexité croissante des systèmes embarqués dans les camions modernes, MAROC TRUCK s'est rapidement imposée comme un leader technique. Nous accompagnons les transporteurs dans la modernisation et l'entretien de leurs véhicules avec une approche axée sur la précision.
            </p>
            <p className="text-zinc-400 leading-relaxed">
              Notre vision est de devenir le centre d'excellence en diagnostic électronique le plus avancé du pays, en investissant continuellement dans les dernières technologies et la formation de nos experts.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4">
             <img src="https://picsum.photos/seed/truck1/400/500" className="rounded-2xl h-80 w-full object-cover grayscale hover:grayscale-0 transition-all duration-500" alt="About 1" />
             <img src="https://picsum.photos/seed/truck2/400/500" className="rounded-2xl h-80 w-full object-cover mt-8 grayscale hover:grayscale-0 transition-all duration-500" alt="About 2" />
          </div>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {[
            { icon: <Target className="w-8 h-8" />, title: 'Précision', desc: 'Chaque diagnostic est vérifié avec des outils de pointe.' },
            { icon: <Lightbulb className="w-8 h-8" />, title: 'Innovation', desc: 'Nous maîtrisons les derniers calculateurs ECU.' },
            { icon: <Users className="w-8 h-8" />, title: 'Proximité', desc: 'Un service client réactif et à votre écoute.' },
            { icon: <Award className="w-8 h-8" />, title: 'Qualité', desc: 'Engagement pour une maintenance durable.' },
          ].map((v, i) => (
            <div key={i} className="bg-zinc-900 border border-zinc-800 p-8 rounded-3xl text-center group hover:border-green-500/50 transition-all">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-zinc-800 rounded-2xl text-yellow-500 mb-6 group-hover:bg-green-600 group-hover:text-white transition-all">
                {v.icon}
              </div>
              <h3 className="text-xl font-bold mb-3">{v.title}</h3>
              <p className="text-zinc-500 text-sm">{v.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
