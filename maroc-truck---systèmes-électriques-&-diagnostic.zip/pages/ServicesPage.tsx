
import React from 'react';
import { Cpu, Zap, Activity, ShieldAlert, Settings, Wrench } from 'lucide-react';
import ServiceCard from '../components/ServiceCard';
import { Service } from '../types';

const ServicesPage: React.FC = () => {
  const services: Service[] = [
    {
      id: '1',
      title: 'Diagnostic électronique',
      description: 'Analyse complète des systèmes embarqués (moteur, ABS/EBS, boîte de vitesses, confort) avec outils constructeurs.',
      icon: <Activity className="w-8 h-8" />
    },
    {
      id: '2',
      title: 'Systèmes électriques',
      description: 'Réparation de faisceaux, alternateurs, démarreurs et circuits d\'éclairage pour tous types de camions.',
      icon: <Zap className="w-8 h-8" />
    },
    {
      id: '3',
      title: 'Codes Défauts',
      description: 'Lecture, interprétation experte et suppression des codes défauts stockés dans les calculateurs.',
      icon: <ShieldAlert className="w-8 h-8" />
    },
    {
      id: '4',
      title: 'Programmation ECU',
      description: 'Mise à jour logiciel, clonage de calculateurs et programmation de clés ou modules de rechange.',
      icon: <Cpu className="w-8 h-8" />
    },
    {
      id: '5',
      title: 'Maintenance technique',
      description: 'Support technique et maintenance préventive pour éviter les pannes lourdes et coûteuses.',
      icon: <Settings className="w-8 h-8" />
    },
    {
      id: '6',
      title: 'Assistance Multi-marques',
      description: 'Expertise sur Volvo, Scania, DAF, Mercedes, Renault, IVECO, MAN et remorques (Wabco/Knorr).',
      icon: <Wrench className="w-8 h-8" />
    }
  ];

  return (
    <div className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-16">
          <h1 className="text-4xl md:text-6xl font-black mb-6">Nos <span className="gradient-text">Expertises</span></h1>
          <p className="text-zinc-400 text-lg">
            Découvrez notre gamme complète de services spécialisés pour maintenir votre flotte de poids lourds en parfait état de fonctionnement.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map(service => (
            <ServiceCard key={service.id} service={service} />
          ))}
        </div>

        <div className="mt-20 p-12 bg-green-600 rounded-3xl relative overflow-hidden group">
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="max-w-2xl text-center md:text-left">
              <h2 className="text-3xl font-bold text-white mb-4 italic">Un problème complexe ?</h2>
              <p className="text-green-100 text-lg">
                Nos experts sont formés pour résoudre les pannes que les autres ne trouvent pas. Diagnostic approfondi avec rapport détaillé.
              </p>
            </div>
            <a href="#/contact" className="bg-white text-green-700 px-10 py-4 rounded-full font-black text-lg hover:bg-yellow-500 hover:text-white transition-all transform hover:scale-105 shrink-0">
              Réserver un diagnostic
            </a>
          </div>
          {/* Background decoration */}
          <div className="absolute top-0 right-0 p-8 text-white/10 group-hover:rotate-12 transition-transform duration-700">
            <Cpu className="w-64 h-64" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServicesPage;
