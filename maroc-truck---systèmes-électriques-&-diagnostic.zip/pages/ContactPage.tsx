
import React, { useState } from 'react';
import { Send, Phone, Mail, MapPin, Clock } from 'lucide-react';

const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate submission
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Info Side */}
          <div>
            <h1 className="text-4xl md:text-6xl font-black mb-8">Contactez <span className="gradient-text">L'Expert</span></h1>
            <p className="text-zinc-400 text-lg mb-12">
              Besoin d'un diagnostic urgent ? D'un devis pour l'entretien de votre flotte ? Notre équipe est prête à intervenir.
            </p>

            <div className="space-y-8">
              <div className="flex items-start gap-6">
                <div className="w-14 h-14 bg-zinc-900 rounded-2xl flex items-center justify-center text-green-500 shrink-0 border border-zinc-800">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-zinc-100 text-lg">Appelez-nous</h4>
                  <p className="text-zinc-400">+212 5XX XX XX XX</p>
                  <p className="text-zinc-500 text-sm">Lundi - Samedi: 8h00 - 18h00</p>
                </div>
              </div>

              <div className="flex items-start gap-6">
                <div className="w-14 h-14 bg-zinc-900 rounded-2xl flex items-center justify-center text-yellow-500 shrink-0 border border-zinc-800">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-zinc-100 text-lg">Email</h4>
                  <p className="text-zinc-400">contact@maroctruck.ma</p>
                  <p className="text-zinc-500 text-sm">Réponse sous 24h ouvrées</p>
                </div>
              </div>

              <div className="flex items-start gap-6">
                <div className="w-14 h-14 bg-zinc-900 rounded-2xl flex items-center justify-center text-green-500 shrink-0 border border-zinc-800">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-zinc-100 text-lg">Localisation</h4>
                  <p className="text-zinc-400">Zone Industrielle, Tit Mellil, Casablanca</p>
                  <p className="text-zinc-500 text-sm">Maroc</p>
                </div>
              </div>
            </div>
          </div>

          {/* Form Side */}
          <div className="bg-zinc-900 p-8 sm:p-12 rounded-3xl border border-zinc-800 relative overflow-hidden">
             {submitted ? (
               <div className="flex flex-col items-center justify-center h-full text-center py-20 space-y-4">
                 <div className="w-20 h-20 bg-green-500/20 text-green-500 rounded-full flex items-center justify-center mb-4">
                   <Send className="w-10 h-10" />
                 </div>
                 <h3 className="text-2xl font-bold">Message Envoyé !</h3>
                 <p className="text-zinc-400">Merci de nous avoir contactés. Nos techniciens reviendront vers vous très bientôt.</p>
               </div>
             ) : (
               <form onSubmit={handleSubmit} className="space-y-6">
                 <div className="grid md:grid-cols-2 gap-6">
                   <div className="space-y-2">
                     <label className="text-sm font-medium text-zinc-400">Nom Complet</label>
                     <input 
                       required
                       type="text" 
                       className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-green-500 transition-colors"
                       placeholder="Votre nom"
                       onChange={(e) => setFormData({...formData, name: e.target.value})}
                     />
                   </div>
                   <div className="space-y-2">
                     <label className="text-sm font-medium text-zinc-400">Téléphone</label>
                     <input 
                       required
                       type="tel" 
                       className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-green-500 transition-colors"
                       placeholder="+212 6..."
                       onChange={(e) => setFormData({...formData, phone: e.target.value})}
                     />
                   </div>
                 </div>
                 <div className="space-y-2">
                   <label className="text-sm font-medium text-zinc-400">Email Professionnel</label>
                   <input 
                     required
                     type="email" 
                     className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-green-500 transition-colors"
                     placeholder="votre@email.com"
                     onChange={(e) => setFormData({...formData, email: e.target.value})}
                   />
                 </div>
                 <div className="space-y-2">
                   <label className="text-sm font-medium text-zinc-400">Message / Symptômes Camion</label>
                   <textarea 
                     required
                     rows={5}
                     className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:border-green-500 transition-colors resize-none"
                     placeholder="Décrivez votre besoin technique..."
                     onChange={(e) => setFormData({...formData, message: e.target.value})}
                   ></textarea>
                 </div>
                 <button 
                   type="submit"
                   className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 transition-all transform hover:scale-[1.02]"
                 >
                   Envoyer la demande
                   <Send className="w-5 h-5" />
                 </button>
               </form>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
