
import React from 'react';
import { CheckCircle2, Award, Zap, HeartHandshake, ShieldCheck } from 'lucide-react';

const WhyChooseUs: React.FC = () => {
  const points = [
    {
      title: 'Expertise Poids Lourds Native',
      desc: 'Contrairement aux garages généralistes, nous sommes 100% dédiés aux camions et engins lourds.',
      icon: <Award className="w-10 h-10" />
    },
    {
      title: 'Équipement de Pointe',
      desc: 'Investissement massif dans les interfaces de diagnostic originales constructeurs.',
      icon: <Zap className="w-10 h-10" />
    },
    {
      title: 'Rapidité d\'Exécution',
      desc: 'Nous comprenons l\'urgence. Diagnostics clairs et rapides pour une reprise de route immédiate.',
      icon: <ShieldCheck className="w-10 h-10" />
    },
    {
      title: 'Satisfaction Garantie',
      desc: 'Accompagnement après intervention et conseils pour la pérennité de vos véhicules.',
      icon: <HeartHandshake className="w-10 h-10" />
    }
  ];

  return (
    <div className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div>
            <h1 className="text-4xl md:text-6xl font-black mb-8">Pourquoi Choisir <span className="gradient-text">MAROC TRUCK</span> ?</h1>
            <p className="text-zinc-400 text-lg mb-12 leading-relaxed">
              Nous ne nous contentons pas de lire des codes défauts. Nous analysons les causes profondes, réparons les composants électroniques et optimisons les paramètres pour garantir la rentabilité de votre logistique.
            </p>
            
            <div className="space-y-4">
              {[
                'Techniciens certifiés multi-marques',
                'Intervention mobile dans tout le Maroc',
                'Solutions logicielles constructeurs (Odis, Xentry, Volvo Tech Tool)',
                'Garantie sur toutes nos interventions électroniques',
                'Expertise en programmation AD-BLUE et DPF'
              ].map((text, i) => (
                <div key={i} className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500 shrink-0" />
                  <span className="text-zinc-200 font-medium">{text}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {points.map((p, i) => (
              <div key={i} className="p-8 bg-zinc-900 border border-zinc-800 rounded-3xl hover:bg-zinc-800/50 transition-all border-b-4 border-b-yellow-500">
                <div className="text-green-500 mb-6">{p.icon}</div>
                <h3 className="text-xl font-bold mb-4">{p.title}</h3>
                <p className="text-zinc-400 text-sm">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WhyChooseUs;
